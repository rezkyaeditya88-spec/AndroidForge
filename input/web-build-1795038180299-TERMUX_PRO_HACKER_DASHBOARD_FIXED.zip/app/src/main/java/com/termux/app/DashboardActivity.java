package com.termux.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * TERMUX PRO visual home screen. The actual terminal, shell, bootstrap and package
 * manager remain the upstream Termux implementation; this activity is only a launcher UI.
 */
public class DashboardActivity extends Activity {
    private final int bg = Color.rgb(5, 10, 12);
    private final int panel = Color.rgb(13, 23, 25);
    private final int panel2 = Color.rgb(17, 31, 31);
    private final int neon = Color.rgb(0, 255, 145);
    private final int muted = Color.rgb(150, 178, 168);
    private final int white = Color.rgb(231, 245, 239);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(0);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(28));
        scroll.addView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(top, new LinearLayout.LayoutParams(-1, -2));

        TextView mark = text("▣", 30, neon, true);
        top.addView(mark, new LinearLayout.LayoutParams(dp(42), -2));
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        brand.addView(text("TERMUX PRO", 23, white, true));
        brand.addView(text("NATIVE TERMINAL ENVIRONMENT", 10, neon, true));
        TextView online = text("● CORE", 11, neon, true);
        online.setPadding(dp(10), dp(7), dp(10), dp(7));
        online.setBackground(shape(panel2, neon, 1, 30));
        top.addView(online);

        TextView intro = text("CONTROL CENTER", 12, muted, true);
        intro.setLetterSpacing(0.18f);
        LinearLayout.LayoutParams introLp = new LinearLayout.LayoutParams(-1, -2);
        introLp.topMargin = dp(30);
        root.addView(intro, introLp);

        TextView headline = text("Your terminal.\nYour tools.", 31, white, true);
        LinearLayout.LayoutParams headLp = new LinearLayout.LayoutParams(-1, -2);
        headLp.topMargin = dp(8);
        root.addView(headline, headLp);

        TextView sub = text("Powered by the official Termux core", 14, muted, false);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(8);
        root.addView(sub, subLp);

        LinearLayout core = new LinearLayout(this);
        core.setOrientation(LinearLayout.VERTICAL);
        core.setPadding(dp(16), dp(16), dp(16), dp(16));
        core.setBackground(shape(panel, Color.rgb(24, 65, 51), 1, 18));
        LinearLayout.LayoutParams coreLp = new LinearLayout.LayoutParams(-1, -2);
        coreLp.topMargin = dp(26);
        root.addView(core, coreLp);
        core.addView(text("▸  TERMUX CORE", 12, neon, true));
        TextView shell = text("Android shell • pkg • apt • bootstrap", 14, white, true);
        LinearLayout.LayoutParams shellLp = new LinearLayout.LayoutParams(-1, -2);
        shellLp.topMargin = dp(10);
        core.addView(shell, shellLp);
        TextView desc = text("The real Termux terminal and package system are retained. This screen is only the new home dashboard.", 12, muted, false);
        LinearLayout.LayoutParams descLp = new LinearLayout.LayoutParams(-1, -2);
        descLp.topMargin = dp(7);
        core.addView(desc, descLp);

        View open = action("⌁   OPEN TERMINAL", "Run commands in the original Termux terminal", true);
        LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(-1, -2);
        openLp.topMargin = dp(22);
        root.addView(open, openLp);
        open.setOnClickListener(v -> startActivity(new Intent(this, TermuxActivity.class)));

        View settings = action("⚙   SETTINGS", "Terminal preferences and appearance", false);
        LinearLayout.LayoutParams settingsLp = new LinearLayout.LayoutParams(-1, -2);
        settingsLp.topMargin = dp(12);
        root.addView(settings, settingsLp);
        settings.setOnClickListener(v -> startActivity(new Intent(this, com.termux.app.activities.SettingsActivity.class)));

        TextView toolsTitle = text("TOOLS YOU CAN INSTALL", 12, muted, true);
        LinearLayout.LayoutParams toolsLp = new LinearLayout.LayoutParams(-1, -2);
        toolsLp.topMargin = dp(28);
        root.addView(toolsTitle, toolsLp);

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams toolsRowLp = new LinearLayout.LayoutParams(-1, -2);
        toolsRowLp.topMargin = dp(12);
        root.addView(tools, toolsRowLp);
        tools.addView(chip("PYTHON"), weighted());
        tools.addView(chip("NODE.JS"), weightedWithMargin());
        tools.addView(chip("GIT"), weightedWithMargin());

        TextView hint = text("TIP  ·  Install tools from the terminal with:  pkg install <package>", 11, muted, false);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, -2);
        hintLp.topMargin = dp(18);
        root.addView(hint, hintLp);

        TextView footer = text("TERMUX PRO  •  COMMUNITY-BASED UI  •  OPEN-SOURCE CORE", 9, Color.rgb(92, 119, 109), true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(-1, -2);
        footerLp.topMargin = dp(34);
        root.addView(footer, footerLp);

        setContentView(scroll);
    }

    private View action(String title, String detail, boolean primary) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(17), dp(15), dp(17), dp(15));
        box.setBackground(shape(primary ? panel2 : panel, primary ? neon : Color.rgb(42, 65, 59), 1, 16));
        TextView t = text(title, 16, primary ? neon : white, true);
        box.addView(t);
        TextView d = text(detail, 11, muted, false);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1, -2);
        dlp.topMargin = dp(5);
        box.addView(d, dlp);
        box.setClickable(true);
        box.setFocusable(true);
        return box;
    }

    private TextView chip(String label) {
        TextView v = text("⌘  " + label, 10, neon, true);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(5), dp(13), dp(5), dp(13));
        v.setBackground(shape(panel2, Color.rgb(30, 75, 59), 1, 12));
        return v;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, -2, 1);
    }

    private LinearLayout.LayoutParams weightedWithMargin() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.leftMargin = dp(7);
        return lp;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setFontFeatureSettings("kern");
        if (bold) v.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        else v.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        return v;
    }

    private GradientDrawable shape(int color, int stroke, int strokeWidth, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(strokeWidth), stroke);
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
