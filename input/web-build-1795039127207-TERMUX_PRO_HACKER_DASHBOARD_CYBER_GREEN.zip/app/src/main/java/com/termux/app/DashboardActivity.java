package com.termux.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Locale;

public class DashboardActivity extends Activity {
    private static final int BG = Color.rgb(3, 8, 7);
    private static final int PANEL = Color.rgb(8, 19, 15);
    private static final int PANEL_ALT = Color.rgb(11, 27, 20);
    private static final int GREEN = Color.rgb(0, 255, 132);
    private static final int GREEN_SOFT = Color.rgb(104, 220, 157);
    private static final int MUTED = Color.rgb(111, 145, 127);
    private static final int WHITE = Color.rgb(225, 246, 233);
    private LinearLayout root;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(28));
        scroll.addView(root);

        LinearLayout header = row();
        root.addView(header, lp(-1, -2));
        TextView logo = text("⌬", 31, GREEN, true);
        header.addView(logo, lp(dp(42), -2));
        LinearLayout name = new LinearLayout(this);
        name.setOrientation(LinearLayout.VERTICAL);
        header.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        name.addView(text("TERMUX PRO", 22, WHITE, true));
        name.addView(text("CYBER CONTROL INTERFACE", 9, GREEN, true));
        TextView live = text("● ONLINE", 10, GREEN, true);
        live.setPadding(dp(10), dp(7), dp(10), dp(7));
        live.setBackground(shape(PANEL_ALT, GREEN, 1, 30));
        header.addView(live);

        addGap(23);
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), dp(19), dp(18), dp(18));
        hero.setBackground(shape(PANEL_ALT, Color.rgb(0, 112, 61), 1, 18));
        root.addView(hero, lp(-1, -2));
        hero.addView(text("SYSTEM ACCESS  /  DASHBOARD", 10, GREEN, true));
        TextView title = text("CONTROL\\nYOUR SYSTEM", 29, WHITE, true);
        LinearLayout.LayoutParams tp = lp(-1, -2); tp.topMargin = dp(9); hero.addView(title, tp);
        TextView subtitle = text("Terminal tools • Device insights • Developer workspace", 11, MUTED, false);
        LinearLayout.LayoutParams sp = lp(-1, -2); sp.topMargin = dp(8); hero.addView(subtitle, sp);
        TextView line = text("━━━━━━━━━━━━━━━━━━━━━━━━━━━━", 12, GREEN, true);
        LinearLayout.LayoutParams linep = lp(-1, -2); linep.topMargin = dp(13); hero.addView(line, linep);

        addSection("LIVE SYSTEM SNAPSHOT");
        LinearLayout stats = row();
        root.addView(stats, lp(-1, -2));
        stats.addView(statCard("MEMORY", memoryValue(), "RAM STATUS"), weighted());
        LinearLayout.LayoutParams second = weighted(); second.leftMargin = dp(9);
        stats.addView(statCard("STORAGE", storageValue(), "INTERNAL"), second);

        addSection("PRIMARY ACCESS");
        addCard("⌁", "OPEN TERMINAL", "Launch the original Termux shell", true,
            () -> startActivity(new Intent(this, TermuxActivity.class)));
        addCard("⚙", "TERMUX SETTINGS", "Preferences and terminal configuration", false,
            () -> startActivity(new Intent(this, com.termux.app.activities.SettingsActivity.class)));

        addSection("SYSTEM INTELLIGENCE");
        addCard("▤", "SYSTEM MONITOR", "RAM, storage, Android and CPU load details", false,
            () -> showSystemInfo());
        addCard("⌁", "NETWORK MONITOR", "Current Android network connection status", false,
            () -> showNetworkInfo());
        addCard("▣", "FILE MANAGER", "Browse files accessible to this application", false,
            () -> showFiles());

        addSection("DEVELOPER WORKSPACE");
        LinearLayout chips = row();
        root.addView(chips, lp(-1, -2));
        chips.addView(chip("PYTHON"), weighted());
        LinearLayout.LayoutParams cp = weighted(); cp.leftMargin = dp(7);
        chips.addView(chip("NODE.JS"), cp);
        LinearLayout.LayoutParams cp2 = weighted(); cp2.leftMargin = dp(7);
        chips.addView(chip("GIT"), cp2);
        addCard("⌘", "PACKAGE COMMANDS", "Open terminal to manage packages with pkg", false,
            () -> startActivity(new Intent(this, TermuxActivity.class)));

        addSection("PERSONALIZATION");
        addCard("◈", "APPEARANCE", "Cyber green interface theme", false,
            () -> showAppearance());
        addCard("ⓘ", "ABOUT TERMUX PRO", "Application and device information", false,
            () -> showAbout());

        addGap(25);
        TextView footer = text("TERMUX PRO  //  CYBER GREEN EDITION\\nSECURE • LOCAL • OPEN SOURCE CORE", 9, MUTED, true);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, lp(-1, -2));
        setContentView(scroll);
    }

    private void addSection(String label) {
        TextView t = text("▸  " + label, 11, GREEN_SOFT, true);
        LinearLayout.LayoutParams p = lp(-1, -2);
        p.topMargin = dp(23); p.bottomMargin = dp(10);
        root.addView(t, p);
    }
    private void addCard(String icon, String title, String detail, boolean primary, Runnable action) {
        LinearLayout card = row();
        card.setPadding(dp(14), dp(15), dp(13), dp(15));
        card.setBackground(shape(primary ? PANEL_ALT : PANEL,
            primary ? GREEN : Color.rgb(26, 65, 43), primary ? 1 : 1, 14));
        TextView glyph = text(icon, 22, GREEN, true);
        glyph.setGravity(Gravity.CENTER);
        card.addView(glyph, lp(dp(38), -2));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams copyParams = new LinearLayout.LayoutParams(0, -2, 1);
        copyParams.leftMargin = dp(9);
        card.addView(copy, copyParams);
        copy.addView(text(title, 13, primary ? GREEN : WHITE, true));
        TextView desc = text(detail, 10, MUTED, false);
        LinearLayout.LayoutParams dp2 = lp(-1, -2); dp2.topMargin = dp(4);
        copy.addView(desc, dp2);
        card.addView(text("›", 25, GREEN_SOFT, true));
        card.setClickable(true); card.setFocusable(true); card.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = lp(-1, -2); p.topMargin = dp(9); root.addView(card, p);
    }
    private View statCard(String label, String value, String foot) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(13), dp(13), dp(10), dp(13));
        box.setBackground(shape(PANEL, Color.rgb(25, 75, 48), 1, 13));
        box.addView(text(label, 9, MUTED, true));
        TextView val = text(value, 19, GREEN, true);
        LinearLayout.LayoutParams vp = lp(-1, -2); vp.topMargin = dp(7); box.addView(val, vp);
        TextView f = text(foot, 8, GREEN_SOFT, true);
        LinearLayout.LayoutParams fp = lp(-1, -2); fp.topMargin = dp(5); box.addView(f, fp);
        return box;
    }
    private String memoryValue() {
        try {
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
            return percent(mi.totalMem - mi.availMem, mi.totalMem);
        } catch (Exception e) { return "--"; }
    }
    private String storageValue() {
        try {
            StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
            return percent(fs.getTotalBytes() - fs.getAvailableBytes(), fs.getTotalBytes());
        } catch (Exception e) { return "--"; }
    }
    private String percent(long used, long total) {
        if (total <= 0) return "--";
        return Math.round((used * 100.0) / total) + "%";
    }
    private void showSystemInfo() {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
        StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
        String load = "Unavailable";
        try { BufferedReader r = new BufferedReader(new FileReader("/proc/loadavg")); load = r.readLine(); r.close(); } catch (Exception ignored) {}
        dialog("SYSTEM MONITOR", "DEVICE\\n" + Build.MANUFACTURER + " " + Build.MODEL +
            "\\nANDROID\\n" + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")" +
            "\\n\\nMEMORY\\nTotal: " + bytes(mi.totalMem) + "\\nUsed: " + bytes(mi.totalMem-mi.availMem) +
            "\\nAvailable: " + bytes(mi.availMem) + "\\n\\nSTORAGE\\nTotal: " + bytes(fs.getTotalBytes()) +
            "\\nAvailable: " + bytes(fs.getAvailableBytes()) + "\\n\\nCPU LOAD\\n" + load);
    }
    private void showNetworkInfo() {
        String status = "No active network";
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
            if (c != null) {
                String type = c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi" :
                    c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "Mobile data" :
                    c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ? "Ethernet" : "Other";
                status = "Connected\\nType: " + type + "\\nInternet capability: " +
                    (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ? "Available" : "Not reported") +
                    "\\nValidated: " + (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ? "Yes" : "No");
            }
        } catch (Exception e) { status = "Unable to read network status."; }
        dialog("NETWORK MONITOR", status + "\\n\\nDisplays Android network status only.");
    }
    private void showFiles() {
        File folder = getExternalFilesDir(null);
        if (folder == null) folder = getFilesDir();
        File[] files = folder.listFiles();
        StringBuilder b = new StringBuilder("APP-ACCESSIBLE DIRECTORY\\n").append(folder.getAbsolutePath()).append("\\n\\n");
        if (files == null || files.length == 0) b.append("No files found.");
        else for (File f : files) b.append(f.isDirectory() ? "[DIR]  " : "[FILE] ")
            .append(f.getName()).append(f.isFile() ? "  (" + bytes(f.length()) + ")" : "").append("\\n");
        dialog("FILE MANAGER", b.toString());
    }
    private void showAppearance() {
        dialog("CYBER GREEN THEME", "Cyberpunk dark interface with neon green accents is active.\\n\\nMore accent themes can be added in a future update.");
    }
    private void showAbout() {
        dialog("ABOUT TERMUX PRO", "TERMUX PRO\\nCyber Green Edition\\n\\nAndroid: " + Build.VERSION.RELEASE +
            "\\nDevice: " + Build.MODEL + "\\n\\nTerminal and package management are provided by the Termux core.");
    }
    private void dialog(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show();
    }
    private String bytes(long n) {
        if (n < 1024) return n + " B";
        double v = n; String[] units = {"B","KB","MB","GB","TB"}; int i = 0;
        while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
        return String.format(Locale.US, "%.2f %s", v, units[i]);
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private TextView chip(String label) {
        TextView t = text("⌘  " + label, 9, GREEN, true); t.setGravity(Gravity.CENTER);
        t.setPadding(dp(4), dp(13), dp(4), dp(13));
        t.setBackground(shape(PANEL_ALT, Color.rgb(28, 87, 51), 1, 10)); return t;
    }
    private LinearLayout.LayoutParams weighted() { return new LinearLayout.LayoutParams(0, -2, 1); }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }
    private GradientDrawable shape(int color, int stroke, int width, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color);
        d.setCornerRadius(dp(radius)); d.setStroke(dp(width), stroke); return d;
    }
    private void addGap(int height) {
        View v = new View(this); root.addView(v, lp(1, dp(height)));
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
