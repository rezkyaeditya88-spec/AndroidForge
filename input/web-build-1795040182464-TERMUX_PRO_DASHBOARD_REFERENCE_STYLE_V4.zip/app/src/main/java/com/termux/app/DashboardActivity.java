package com.termux.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Locale;

public class DashboardActivity extends Activity {
    private static final int BLACK = Color.rgb(7, 9, 9);
    private static final int CARD = Color.rgb(19, 23, 22);
    private static final int CARD2 = Color.rgb(25, 31, 29);
    private static final int GREEN = Color.rgb(0, 239, 155);
    private static final int MINT = Color.rgb(159, 238, 204);
    private static final int WHITE = Color.rgb(239, 246, 242);
    private static final int GREY = Color.rgb(147, 160, 153);
    private LinearLayout root;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BLACK);
        getWindow().setNavigationBarColor(Color.rgb(12, 14, 13));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BLACK);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(20));
        scroll.addView(root);

        LinearLayout header = row();
        root.addView(header, lp(-1, -2));
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        brand.addView(text("TERMUX PRO", 20, WHITE, true));
        brand.addView(text("CYBER SECURITY STYLE • GREEN EDITION", 9, GREEN, true));
        TextView status = text("● ACTIVE", 10, GREEN, true);
        status.setPadding(dp(10), dp(7), dp(10), dp(7));
        status.setBackground(shape(CARD2, GREEN, 1, 24));
        header.addView(status);

        addGap(25);
        root.addView(text("WELCOME BACK", 10, GREEN, true));
        TextView hero = text("YOUR DEVICE IS\\nREADY.", 27, WHITE, true);
        LinearLayout.LayoutParams hp = lp(-1, -2); hp.topMargin = dp(7); root.addView(hero, hp);
        TextView intro = text("Terminal tools and system information in one place.", 11, GREY, false);
        LinearLayout.LayoutParams ip = lp(-1, -2); ip.topMargin = dp(6); root.addView(intro, ip);

        addSection("SYSTEM OVERVIEW");
        LinearLayout overview = row();
        root.addView(overview, lp(-1, -2));
        overview.addView(scoreCard(), new LinearLayout.LayoutParams(0, dp(150), 1.12f));
        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams sidep = new LinearLayout.LayoutParams(0, dp(150), 0.88f);
        sidep.leftMargin = dp(8); overview.addView(side, sidep);
        side.addView(metricCard("RAM USED", memoryPercent(), "MEMORY"));
        View gap = new View(this); side.addView(gap, lp(1, dp(7)));
        side.addView(metricCard("STORAGE", storagePercent(), "INTERNAL"));

        addSection("QUICK ACCESS");
        addCard("⌁", "OPEN TERMINAL", "Launch your Termux command line", true,
            () -> startActivity(new Intent(this, TermuxActivity.class)));
        addCard("▣", "FILE MANAGER", "View files accessible to this app", false, () -> showFiles());
        addCard("◉", "SYSTEM MONITOR", "Device, memory, storage and CPU load", false, () -> showSystem());
        addCard("⌖", "NETWORK STATUS", "Check the current connection type", false, () -> showNetwork());

        addSection("DEVELOPER WORKSPACE");
        LinearLayout chips = row();
        root.addView(chips, lp(-1, -2));
        chips.addView(chip("PYTHON"), weighted());
        LinearLayout.LayoutParams c2 = weighted(); c2.leftMargin = dp(7); chips.addView(chip("NODE.JS"), c2);
        LinearLayout.LayoutParams c3 = weighted(); c3.leftMargin = dp(7); chips.addView(chip("GIT"), c3);

        addSection("APP SETTINGS");
        addCard("⚙", "SETTINGS", "Open original Termux preferences", false,
            () -> startActivity(new Intent(this, com.termux.app.activities.SettingsActivity.class)));
        addCard("ⓘ", "ABOUT TERMUX PRO", "Version and device information", false, () -> showAbout());

        addGap(20);
        TextView footer = text("TERMUX PRO  •  CYBER GREEN", 9, GREY, true);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, lp(-1, -2));
        setContentView(scroll);
    }

    private View scoreCard() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(10), dp(12), dp(10), dp(12));
        box.setBackground(shape(MINT, MINT, 1, 13));
        TextView title = text("SYSTEM STATUS", 9, Color.rgb(16, 60, 43), true);
        box.addView(title);
        TextView icon = text("✓", 38, Color.rgb(5, 88, 54), true);
        LinearLayout.LayoutParams a = lp(-2, -2); a.topMargin = dp(8); box.addView(icon, a);
        TextView state = text("READY", 18, Color.rgb(5, 65, 43), true);
        LinearLayout.LayoutParams b = lp(-2, -2); b.topMargin = dp(2); box.addView(state, b);
        return box;
    }
    private View metricCard(String title, String value, String sub) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(11), dp(8), dp(8), dp(7));
        box.setBackground(shape(CARD2, Color.rgb(47, 66, 57), 1, 11));
        box.addView(text(title, 8, GREY, true));
        TextView v = text(value, 19, GREEN, true);
        LinearLayout.LayoutParams p = lp(-1, -2); p.topMargin = dp(3); box.addView(v, p);
        box.addView(text(sub, 8, MINT, true));
        return box;
    }
    private void addSection(String s) {
        TextView t = text("▰  " + s, 10, GREEN, true);
        LinearLayout.LayoutParams p = lp(-1, -2);
        p.topMargin = dp(22); p.bottomMargin = dp(9); root.addView(t, p);
    }
    private void addCard(String glyph, String title, String desc, boolean primary, Runnable action) {
        LinearLayout card = row();
        card.setPadding(dp(13), dp(13), dp(12), dp(13));
        card.setBackground(shape(CARD, primary ? GREEN : Color.rgb(48, 61, 54), 1, 12));
        TextView icon = text(glyph, 21, GREEN, true);
        icon.setGravity(Gravity.CENTER);
        card.addView(icon, lp(dp(35), -2));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1);
        cp.leftMargin = dp(9); card.addView(content, cp);
        content.addView(text(title, 12, primary ? GREEN : WHITE, true));
        TextView d = text(desc, 9, GREY, false);
        LinearLayout.LayoutParams dp2 = lp(-1, -2); dp2.topMargin = dp(4); content.addView(d, dp2);
        card.addView(text("›", 23, MINT, true));
        card.setClickable(true); card.setFocusable(true); card.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = lp(-1, -2); p.topMargin = dp(8); root.addView(card, p);
    }
    private String memoryPercent() {
        try {
            ActivityManager.MemoryInfo m = new ActivityManager.MemoryInfo();
            ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m);
            return pct(m.totalMem - m.availMem, m.totalMem);
        } catch (Exception e) { return "--"; }
    }
    private String storagePercent() {
        try {
            StatFs s = new StatFs(Environment.getDataDirectory().getPath());
            return pct(s.getTotalBytes() - s.getAvailableBytes(), s.getTotalBytes());
        } catch (Exception e) { return "--"; }
    }
    private String pct(long used, long total) { return total <= 0 ? "--" : Math.round(used * 100.0 / total) + "%"; }
    private void showSystem() {
        ActivityManager.MemoryInfo m = new ActivityManager.MemoryInfo();
        ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m);
        StatFs s = new StatFs(Environment.getDataDirectory().getPath());
        String load = "Unavailable";
        try { BufferedReader r = new BufferedReader(new FileReader("/proc/loadavg")); load = r.readLine(); r.close(); } catch (Exception ignored) {}
        dialog("SYSTEM MONITOR", "DEVICE: " + Build.MANUFACTURER + " " + Build.MODEL +
            "\\nANDROID: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")" +
            "\\n\\nRAM TOTAL: " + bytes(m.totalMem) + "\\nRAM AVAILABLE: " + bytes(m.availMem) +
            "\\nSTORAGE TOTAL: " + bytes(s.getTotalBytes()) + "\\nSTORAGE FREE: " + bytes(s.getAvailableBytes()) +
            "\\nCPU LOAD: " + load);
    }
    private void showNetwork() {
        String result = "No active network";
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
            if (c != null) {
                String type = c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi" :
                    c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "Mobile data" :
                    c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ? "Ethernet" : "Other";
                result = "Connected\\nType: " + type + "\\nInternet: " +
                    (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ? "Available" : "Not reported");
            }
        } catch (Exception ignored) {}
        dialog("NETWORK STATUS", result);
    }
    private void showFiles() {
        File folder = getExternalFilesDir(null);
        if (folder == null) folder = getFilesDir();
        File[] list = folder.listFiles();
        StringBuilder b = new StringBuilder(folder.getAbsolutePath()).append("\\n\\n");
        if (list == null || list.length == 0) b.append("No files found.");
        else for (File f : list) b.append(f.isDirectory() ? "[DIR] " : "[FILE] ")
            .append(f.getName()).append(f.isFile() ? " (" + bytes(f.length()) + ")" : "").append("\\n");
        dialog("FILE MANAGER", b.toString());
    }
    private void showAbout() {
        dialog("ABOUT TERMUX PRO", "TERMUX PRO • CYBER GREEN\\nAndroid " + Build.VERSION.RELEASE +
            "\\nDevice: " + Build.MODEL + "\\n\\nTerminal and package tools are provided by the Termux core.");
    }
    private void dialog(String title, String msg) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show();
    }
    private String bytes(long n) {
        if (n < 1024) return n + " B";
        double v = n; String[] u = {"B","KB","MB","GB","TB"}; int i = 0;
        while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
        return String.format(Locale.US, "%.1f %s", v, u[i]);
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private TextView chip(String s) {
        TextView t = text("⌘  " + s, 9, GREEN, true); t.setGravity(Gravity.CENTER);
        t.setPadding(dp(3), dp(12), dp(3), dp(12)); t.setBackground(shape(CARD2, Color.rgb(48, 74, 59), 1, 10));
        return t;
    }
    private LinearLayout.LayoutParams weighted() { return new LinearLayout.LayoutParams(0, -2, 1); }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL)); return t;
    }
    private GradientDrawable shape(int color, int stroke, int sw, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(sw), stroke); return d;
    }
    private void addGap(int h) { root.addView(new View(this), lp(1, dp(h))); }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
