package com.termux.app;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.util.List;
import java.util.Locale;

public class DashboardActivity extends Activity {
    private static final int BG=Color.rgb(5,8,7), CARD=Color.rgb(18,23,21),
        GREEN=Color.rgb(0,239,145), MINT=Color.rgb(157,239,202),
        WHITE=Color.rgb(238,247,241), GREY=Color.rgb(145,161,151);
    private LinearLayout root;
    private String locationText="Location permission required";
    private int page=0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(Color.rgb(12,14,13));
        requestStartupPermissions();
        showPage(0);
    }

    private void requestStartupPermissions() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 22);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION}, 21);
        else refreshLocation();
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if(requestCode==21) {
            if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) refreshLocation();
            else locationText="Location permission denied";
            if(root!=null) showPage(page);
        }
        if(requestCode==22 && root!=null) showPage(page);
    }

    private void refreshLocation() {
        try {
            boolean fine=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
            boolean coarse=checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;
            if(!fine&&!coarse){locationText="Location permission required";return;}
            LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
            Location loc=null;
            try { if(lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) loc=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER); } catch(Exception ignored){}
            try { if(loc==null&&lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER); } catch(Exception ignored){}
            if(loc==null){locationText="Permission granted • waiting for location";return;}
            locationText=String.format(Locale.US,"%.4f, %.4f",loc.getLatitude(),loc.getLongitude());
            if(Geocoder.isPresent()) {
                try {
                    List<Address> a=new Geocoder(this,Locale.getDefault()).getFromLocation(loc.getLatitude(),loc.getLongitude(),1);
                    if(a!=null&&!a.isEmpty()) {
                        String city=a.get(0).getLocality();
                        String region=a.get(0).getAdminArea();
                        if(city!=null) locationText=city+(region==null?"":", "+region);
                    }
                } catch(Exception ignored){}
            }
        } catch(SecurityException e){locationText="Location permission required";}
        catch(Exception e){locationText="Location unavailable";}
    }

    private void showPage(int which) {
        page=which;
        ScrollView sc=new ScrollView(this); sc.setFillViewport(true); sc.setBackgroundColor(BG);
        root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(17),dp(17),dp(17),dp(24)); sc.addView(root);
        LinearLayout head=row();
        LinearLayout brand=new LinearLayout(this); brand.setOrientation(1);
        brand.addView(txt("TERMUX PRO",20,WHITE,true));
        brand.addView(txt("CYBER SECURITY • GREEN EDITION",9,GREEN,true));
        head.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        head.addView(txt("● ACTIVE",10,GREEN,true)); root.addView(head,lp(-1,-2));

        LinearLayout loc=cardBox();
        loc.addView(txt("⌖  DEVICE LOCATION",9,GREEN,true));
        TextView place=txt(locationText,13,WHITE,true); LinearLayout.LayoutParams pp=lp(-1,-2);pp.topMargin=dp(5);loc.addView(place,pp);
        TextView locAction=txt("ALLOW / REFRESH LOCATION  ›",9,MINT,true);
        LinearLayout.LayoutParams lap=lp(-1,-2);lap.topMargin=dp(8);loc.addView(locAction,lap);
        locAction.setOnClickListener(v->{
            if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED &&
               checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},21);
            else {refreshLocation();showPage(page);}
        });
        LinearLayout.LayoutParams lcp=lp(-1,-2);lcp.topMargin=dp(17);root.addView(loc,lcp);

        LinearLayout tabs=row(); tabs.setPadding(0,dp(14),0,dp(5));root.addView(tabs,lp(-1,-2));
        addTab(tabs,"WELCOME",0);addTab(tabs,"MONITOR",1);addTab(tabs,"CHECK LINK",2);

        if(which==0) pageWelcome();
        else if(which==1) pageMonitor();
        else pageScanner();

        TextView foot=txt("TERMUX PRO  •  CYBER GREEN",9,GREY,true);foot.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp=lp(-1,-2);fp.topMargin=dp(22);root.addView(foot,fp);
        setContentView(sc);
    }

    private void pageWelcome() {
        gap(17);root.addView(txt("WELCOME BACK",10,GREEN,true));
        TextView title=txt("YOUR DEVICE IS\\nREADY.",27,WHITE,true);LinearLayout.LayoutParams tp=lp(-1,-2);tp.topMargin=dp(6);root.addView(title,tp);
        TextView desc=txt("Security overview and quick access to your tools.",11,GREY,false);LinearLayout.LayoutParams dp1=lp(-1,-2);dp1.topMargin=dp(5);root.addView(desc,dp1);
        section("SECURITY OVERVIEW");
        LinearLayout row=row();root.addView(row,lp(-1,dp(140)));
        LinearLayout score=cardBox();score.setGravity(Gravity.CENTER);score.addView(txt("SYSTEM STATUS",9,Color.rgb(18,73,48),true));
        TextView n=txt("READY",25,Color.rgb(5,75,47),true);score.addView(n);score.addView(txt("BASIC STATUS",8,Color.rgb(18,73,48),true));
        row.addView(score,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout stats=new LinearLayout(this);stats.setOrientation(1);LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(0,-1,1);stp.leftMargin=dp(8);row.addView(stats,stp);
        stats.addView(metric("RAM USED",memoryPercent()));gapIn(stats,6);stats.addView(metric("STORAGE",storagePercent()));
        section("QUICK ACCESS");
        addAction("⌁","OPEN TERMINAL","Launch the original Termux terminal",()->startActivity(new Intent(this,TermuxActivity.class)));
        addAction("▤","SYSTEM TOOLS","CPU, memory, storage and network",()->showPage(1));
        addAction("⌕","CHECK LINK / MESSAGE","Inspect a URL for suspicious patterns",()->showPage(2));
        addAction("⚙","TERMUX SETTINGS","Preferences and terminal configuration",()->startActivity(new Intent(this,com.termux.app.activities.SettingsActivity.class)));
        addAction("♧","NOTIFICATIONS","Permission status and app notification access",()->notificationInfo());
    }

    private void pageMonitor() {
        gap(18);root.addView(txt("REAL-TIME MONITORING",11,GREEN,true));
        root.addView(txt("DEVICE HEALTH",26,WHITE,true));
        root.addView(txt("Current Android system snapshot",11,GREY,false));
        section("RESOURCE MONITOR");
        addAction("▥","MEMORY USAGE","Used: "+memoryPercent(),()->showSystem());
        addAction("▤","INTERNAL STORAGE","Used: "+storagePercent(),()->showSystem());
        addAction("◉","CPU LOAD","Read current system load average",()->showSystem());
        addAction("⌁","NETWORK STATUS",networkSummary(),()->networkDialog());
        addAction("⌖","LOCATION",locationText,()->refreshLocationAndRender());
        section("DEVICE INFORMATION");
        addAction("▣","DEVICE",Build.MANUFACTURER+" "+Build.MODEL,()->showSystem());
        addAction("◆","ANDROID VERSION",Build.VERSION.RELEASE+" • API "+Build.VERSION.SDK_INT,()->showSystem());
        addAction("↻","REFRESH MONITOR","Update displayed system snapshot",()->showPage(1));
    }

    private void pageScanner() {
        gap(18);root.addView(txt("CHECK LINK / MESSAGE",11,GREEN,true));
        root.addView(txt("LINK SECURITY CHECK",25,WHITE,true));
        root.addView(txt("Check a link before opening it. This is a local pattern check, not a full antivirus scan.",10,GREY,false));
        section("URL INSPECTOR");
        LinearLayout box=cardBox();
        box.addView(txt("PASTE URL",9,GREEN,true));
        EditText input=new EditText(this);input.setSingleLine(true);input.setTextColor(WHITE);input.setHintTextColor(GREY);input.setHint("https://example.com");input.setTextSize(13);
        LinearLayout.LayoutParams ep=lp(-1,dp(52));ep.topMargin=dp(8);box.addView(input,ep);
        TextView check=txt("CHECK LINK",12,Color.BLACK,true);check.setGravity(Gravity.CENTER);check.setPadding(dp(12),dp(13),dp(12),dp(13));check.setBackground(shape(GREEN,GREEN,1,8));
        LinearLayout.LayoutParams bp=lp(-1,-2);bp.topMargin=dp(8);box.addView(check,bp);
        check.setOnClickListener(v->inspectUrl(input.getText().toString()));
        section("SAFETY NOTES");
        addAction("⚠","UNKNOWN LINKS","Avoid links asking for passwords or payment details",()->dialog("SAFETY TIP","Do not enter passwords, OTP codes or payment details on unknown sites."));
        addAction("ⓘ","SCAN LIMITATION","Local checks cannot guarantee a link is safe",()->dialog("ABOUT CHECK LINK","This feature checks URL formatting and common suspicious patterns only. It does not download files or certify a website as safe."));
    }

    private void inspectUrl(String raw) {
        String s=raw==null?"":raw.trim(); if(s.isEmpty()){dialog("CHECK LINK","Please enter a URL first.");return;}
        String lower=s.toLowerCase(Locale.ROOT);StringBuilder out=new StringBuilder();
        boolean suspicious=false;
        try {
            URL u=new URL(s.contains("://")?s:"https://"+s);
            String host=u.getHost();
            if(host==null||host.length()<4) {suspicious=true;out.append("Invalid or unusual host.\\n");}
            if(!"https".equalsIgnoreCase(u.getProtocol())){suspicious=true;out.append("Not using HTTPS.\\n");}
            if(host!=null && (host.matches(".*\\\\d+\\\\.\\\\d+\\\\.\\\\d+\\\\.\\\\d+.*") || host.contains("xn--"))){suspicious=true;out.append("IP-based or encoded hostname.\\n");}
            if(host!=null && host.split("\\\\.").length>5){suspicious=true;out.append("Unusually many subdomains.\\n");}
        } catch(Exception e){suspicious=true;out.append("URL format could not be parsed.\\n");}
        String[] flags={"login-verify","account-suspended","free-gift","claim-prize","password-reset","bit.ly","tinyurl","t.co"};
        for(String f:flags)if(lower.contains(f)){suspicious=true;out.append("Contains suspicious pattern: ").append(f).append("\\n");}
        if(lower.contains("@")){suspicious=true;out.append("Contains @ symbol in URL.\\n");}
        if(!suspicious)out.append("No obvious suspicious pattern found. This does NOT guarantee safety.");
        else out.append("\\nTreat this link as suspicious. Do not enter private information.");
        dialog(suspicious?"⚠ POSSIBLY SUSPICIOUS":"BASIC CHECK RESULT",out.toString());
    }

    private void addTab(LinearLayout tabs,String label,int id) {
        TextView t=txt(label,9,id==page?Color.BLACK:GREEN,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(4),dp(12),dp(4),dp(12));
        t.setBackground(shape(id==page?GREEN:CARD,id==page?GREEN:Color.rgb(44,65,53),1,8));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);if(id>0)p.leftMargin=dp(5);tabs.addView(t,p);t.setOnClickListener(v->showPage(id));
    }
    private void addAction(String icon,String title,String detail,Runnable run) {
        LinearLayout c=row();c.setPadding(dp(12),dp(13),dp(10),dp(13));c.setBackground(shape(CARD,Color.rgb(43,61,51),1,11));
        TextView i=txt(icon,20,GREEN,true);i.setGravity(Gravity.CENTER);c.addView(i,lp(dp(34),-2));
        LinearLayout body=new LinearLayout(this);body.setOrientation(1);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,1);bp.leftMargin=dp(8);c.addView(body,bp);
        body.addView(txt(title,11,WHITE,true));TextView d=txt(detail,9,GREY,false);LinearLayout.LayoutParams dp1=lp(-1,-2);dp1.topMargin=dp(4);body.addView(d,dp1);
        c.addView(txt("›",22,MINT,true));c.setOnClickListener(v->run.run());LinearLayout.LayoutParams p=lp(-1,-2);p.topMargin=dp(8);root.addView(c,p);
    }
    private LinearLayout cardBox(){LinearLayout b=new LinearLayout(this);b.setOrientation(1);b.setPadding(dp(13),dp(12),dp(13),dp(12));b.setBackground(shape(CARD,Color.rgb(43,70,54),1,12));return b;}
    private View metric(String name,String value){LinearLayout b=cardBox();b.addView(txt(name,8,GREY,true));TextView v=txt(value,19,GREEN,true);LinearLayout.LayoutParams p=lp(-1,-2);p.topMargin=dp(4);b.addView(v,p);return b;}
    private void section(String s){TextView t=txt("▰  "+s,10,GREEN,true);LinearLayout.LayoutParams p=lp(-1,-2);p.topMargin=dp(20);p.bottomMargin=dp(8);root.addView(t,p);}
    private void showSystem(){ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo();((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m);StatFs s=new StatFs(Environment.getDataDirectory().getPath());String load="Unavailable";try{BufferedReader r=new BufferedReader(new FileReader("/proc/loadavg"));load=r.readLine();r.close();}catch(Exception ignored){}dialog("SYSTEM MONITOR","Device: "+Build.MANUFACTURER+" "+Build.MODEL+"\\nAndroid: "+Build.VERSION.RELEASE+"\\nRAM: "+bytes(m.availMem)+" available / "+bytes(m.totalMem)+"\\nStorage: "+bytes(s.getAvailableBytes())+" available / "+bytes(s.getTotalBytes())+"\\nCPU load: "+load);}
    private void networkDialog(){dialog("NETWORK STATUS",networkSummary());}
    private String networkSummary(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);Network n=cm.getActiveNetwork();NetworkCapabilities c=n==null?null:cm.getNetworkCapabilities(n);if(c==null)return "No active network";return c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)?"Connected • Wi-Fi":c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)?"Connected • Mobile data":"Connected • Other";}catch(Exception e){return "Network status unavailable";}}
    private void showFiles(){File f=getExternalFilesDir(null);if(f==null)f=getFilesDir();File[] a=f.listFiles();StringBuilder b=new StringBuilder(f.getAbsolutePath()).append("\\n");if(a!=null)for(File x:a)b.append(x.isDirectory()?"[DIR] ":"[FILE] ").append(x.getName()).append("\\n");dialog("FILE MANAGER",b.toString());}
    private void notificationInfo(){if(Build.VERSION.SDK_INT>=33){if(checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},22);else dialog("NOTIFICATIONS","Notification permission is allowed.");}else dialog("NOTIFICATIONS","Android version does not require runtime notification permission.");}
    private void refreshLocationAndRender(){refreshLocation();showPage(1);}
        private String memoryPercent(){try{ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo();((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m);return pct(m.totalMem-m.availMem,m.totalMem);}catch(Exception e){return "--";}}
    private String storagePercent(){try{StatFs s=new StatFs(Environment.getDataDirectory().getPath());return pct(s.getTotalBytes()-s.getAvailableBytes(),s.getTotalBytes());}catch(Exception e){return "--";}}
    private String pct(long a,long b){return b<=0?"--":Math.round(a*100.0/b)+"%";}
    private String bytes(long n){if(n<1024)return n+" B";double v=n;String[]u={"B","KB","MB","GB","TB"};int i=0;while(v>=1024&&i<u.length-1){v/=1024;i++;}return String.format(Locale.US,"%.1f %s",v,u[i]);}
    private void dialog(String t,String m){new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("OK",null).show();}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void gap(int h){root.addView(new View(this),lp(1,dp(h)));}
    private void gapIn(LinearLayout l,int h){l.addView(new View(this),lp(1,dp(h)));}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return t;}
    private GradientDrawable shape(int c,int stroke,int w,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));d.setStroke(dp(w),stroke);return d;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
