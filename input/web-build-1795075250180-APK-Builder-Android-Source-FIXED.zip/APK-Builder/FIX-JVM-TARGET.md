# Fix JVM target mismatch

The build error reported Java target 1.8 while Kotlin targeted 17.
`app/build.gradle.kts` now explicitly sets Java source/target compatibility and Kotlin `jvmTarget` to 17.

This fixes that specific compatibility mismatch. It does not prove the whole app builds; run Gradle again and share any new error log if another issue appears.
