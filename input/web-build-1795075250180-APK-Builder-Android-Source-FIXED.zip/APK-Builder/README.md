# APK Builder — Android project source

This ZIP contains an Android Studio starter project for **APK Builder**, using a blue-and-white dashboard and a custom Android/upload/gear launcher icon.

## Current state
This is a **UI prototype source project**, not a finished or tested APK. The dashboard includes ZIP selection, GitHub token/repository/branch fields, Debug/Release selection, status panel, and navigation. The Build button currently shows an explanatory prototype status; GitHub upload, workflow dispatch, live run monitoring, and artifact download are not implemented in this ZIP yet.

## Build in Android Studio
- JDK 17
- Android SDK 35
- Gradle wrapper distribution: Gradle 8.9
- Open this folder in Android Studio, sync Gradle, then Build > Build APK(s).

Do not enter a real GitHub token in this prototype. GitHub integration and secure token storage must be implemented and tested before using real credentials.
