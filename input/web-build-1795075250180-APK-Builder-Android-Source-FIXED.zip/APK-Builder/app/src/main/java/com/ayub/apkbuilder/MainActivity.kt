package com.ayub.apkbuilder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

private val Blue = Color(0xFF075BEE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Color(0xFFF7FAFF))) {
                var fileName by remember { mutableStateOf("Belum ada file ZIP dipilih") }
                var status by remember { mutableStateOf("Belum ada proses build. Upload proyek untuk memulai.") }
                var token by remember { mutableStateOf("") }
                var owner by remember { mutableStateOf("") }
                var repo by remember { mutableStateOf("") }
                var branch by remember { mutableStateOf("main") }
                var variant by remember { mutableStateOf("Debug") }
                var tab by remember { mutableIntStateOf(0) }
                val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                    if (uri != null) fileName = uri.lastPathSegment ?: "project.zip"
                }
                Scaffold(bottomBar = {
                    NavigationBar(containerColor = Color.White) {
                        NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Dashboard") })
                        NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.History, null) }, label = { Text("Riwayat") })
                        NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.Info, null) }, label = { Text("Tentang") })
                    }
                }) { pad ->
                    Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState())) {
                        Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF034FE0), Color(0xFF1685FF)))).padding(22.dp)) {
                            Text("APK Builder", style = MaterialTheme.typography.headlineLarge, color = Color.White)
                            Text("Build APK dengan mudah!", color = Color.White)
                        }
                        if (tab == 0) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Archive, null, tint = Blue, modifier = Modifier.size(40.dp))
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) { Text("Upload Project", style = MaterialTheme.typography.titleLarge); Text(fileName, style = MaterialTheme.typography.bodySmall) }
                                        Button(onClick = { picker.launch(arrayOf("application/zip", "application/octet-stream")) }) { Icon(Icons.Default.CloudUpload, null); Text("Pilih File") }
                                    }
                                }
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("Pengaturan Build", style = MaterialTheme.typography.titleLarge)
                                        OutlinedTextField(token, { token = it }, Modifier.fillMaxWidth(), label = { Text("GitHub Token") })
                                        OutlinedTextField(owner, { owner = it }, Modifier.fillMaxWidth(), label = { Text("GitHub username / owner") })
                                        OutlinedTextField(repo, { repo = it }, Modifier.fillMaxWidth(), label = { Text("Nama repository") })
                                        OutlinedTextField(branch, { branch = it }, Modifier.fillMaxWidth(), label = { Text("Branch") })
                                        Text("Build Variant")
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            FilterChip(variant == "Debug", { variant = "Debug" }, label = { Text("Debug") })
                                            FilterChip(variant == "Release", { variant = "Release" }, label = { Text("Release") })
                                        }
                                        Button(onClick = { status = "Tampilan awal siap. Integrasi GitHub Actions perlu diselesaikan dan diuji sebelum build sungguhan." }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                                            Icon(Icons.Default.Build, null); Spacer(Modifier.width(8.dp)); Text("Mulai Build")
                                        }
                                    }
                                }
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text("Status Build", style = MaterialTheme.typography.titleLarge)
                                        Spacer(Modifier.height(8.dp))
                                        Surface(color = Color(0xFFEAF2FF), shape = MaterialTheme.shapes.medium) { Text(status, Modifier.fillMaxWidth().padding(14.dp)) }
                                    }
                                }
                                Text("Token jangan dibagikan kepada siapa pun. Versi ini adalah prototipe UI.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                        } else {
                            Column(Modifier.padding(20.dp)) { Text(if (tab == 1) "Riwayat Build" else "Tentang APK Builder", style = MaterialTheme.typography.headlineSmall); Text(if (tab == 1) "Riwayat build akan tersedia setelah integrasi GitHub selesai." else "APK Builder — prototipe aplikasi Android.") }
                        }
                    }
                }
            }
        }
    }
}
