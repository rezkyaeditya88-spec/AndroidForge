# APK Builder - real GitHub Actions build client

The app uploads an Android Gradle ZIP to an existing GitHub repository, adds a GitHub Actions workflow, dispatches a Debug or Release build, monitors the latest workflow run, reads the run result and downloads the APK artifact into Downloads/APKBuilder. The live screen includes a moving hammer animation.

## Requirements
- JDK 17 and Android SDK 35 to compile this Android client.
- An existing GitHub repository and branch (the app does not create repositories).
- Fine-grained GitHub Personal Access Token: Repository permissions Contents = Read and write; Actions = Read and write; Metadata read is included by default.
- ZIP must contain an Android Gradle project, including settings.gradle(.kts), gradlew, gradle/wrapper/gradle-wrapper.jar and gradle-wrapper.properties. A single enclosing folder in the ZIP is automatically stripped.
- Release mode runs assembleRelease. A signed release APK requires signing configuration and credentials in the submitted project/workflow; this app does not invent a signing key.

## Security and limits
Builds execute on GitHub Actions, not on the phone. The app writes uploaded project files into the selected branch as a commit. Never upload secrets, keystores, passwords or private signing credentials in a public repository. The PAT is saved in app-private preferences; revoke it in GitHub if the device is lost. ZIP upload limit in this app is 45 MB; GitHub API rate limits apply.

## Verification status
The ZIP structure was checked. A local Android build could not be completed in this environment because Gradle distribution download was blocked by unavailable network access. The app still needs a real-device build test and a test against a GitHub repository/token.
