package com.ayub.apkbuilder

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.ui.draw.rotate
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private val Blue = Color(0xFF075BEE)
private val http = OkHttpClient.Builder().followRedirects(true).build()
private const val API = "https://api.github.com"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("apk_builder", MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary=Blue, background=Color(0xFFF6F8FC))) {
                var token by remember { mutableStateOf(prefs.getString("token", "") ?: "") }
                var owner by remember { mutableStateOf(prefs.getString("owner", "") ?: "") }
                var repo by remember { mutableStateOf(prefs.getString("repo", "") ?: "") }
                var branch by remember { mutableStateOf(prefs.getString("branch", "main") ?: "main") }
                var zipUri by remember { mutableStateOf<Uri?>(null) }
                var zipName by remember { mutableStateOf("Belum ada ZIP dipilih") }
                var variant by remember { mutableStateOf("Debug") }
                var tab by remember { mutableIntStateOf(0) }
                var busy by remember { mutableStateOf(false) }
                var progress by remember { mutableIntStateOf(0) }
                var status by remember { mutableStateOf("Siap menerima project") }
                var logs by remember { mutableStateOf(listOf<String>()) }
                var history by remember { mutableStateOf(prefs.getString("history", "")!!.split("\n").filter { it.isNotBlank() }) }
                var apkSaved by remember { mutableStateOf("") }
                val hammerMotion = rememberInfiniteTransition(label="hammer").animateFloat(initialValue=-12f,targetValue=12f,animationSpec=infiniteRepeatable(animation=tween(320),repeatMode=RepeatMode.Reverse),label="hammer-angle")
                var tokenScreen by remember { mutableStateOf(token.isBlank()) }
                val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) { zipUri=u; zipName=u.lastPathSegment ?: "project.zip" } }
                fun log(s:String) { logs = logs + s }
                fun persist() { prefs.edit().putString("token",token).putString("owner",owner).putString("repo",repo).putString("branch",branch).apply() }
                Scaffold(bottomBar={ NavigationBar { listOf("Build APK","Riwayat","Panduan","Info").forEachIndexed { i, label -> NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(when(i){0->Icons.Default.Build;1->Icons.Default.History;2->Icons.Default.MenuBook;else->Icons.Default.Info},null)},label={Text(label)}) } } }) { pad ->
                    Column(Modifier.fillMaxSize().padding(pad)) {
                        Column(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF0649C8),Color(0xFF168BFF)))).padding(20.dp)) {
                            Text("APK BUILDER",style=MaterialTheme.typography.headlineMedium,color=Color.White)
                            Text(if(tokenScreen) "Hubungkan GitHub untuk memulai" else "Build Android project melalui GitHub Actions",color=Color.White)
                        }
                        if(tokenScreen) {
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                                Text("Hubungkan GitHub",style=MaterialTheme.typography.headlineSmall)
                                Text("Masukkan Personal Access Token. Token disimpan lokal pada perangkat ini dan tidak dikirim ke layanan selain api.github.com.")
                                OutlinedTextField(token,{token=it},Modifier.fillMaxWidth(),label={Text("GitHub Token")},visualTransformation=PasswordVisualTransformation(),singleLine=true)
                                OutlinedTextField(owner,{owner=it},Modifier.fillMaxWidth(),label={Text("GitHub username / owner")},singleLine=true)
                                OutlinedTextField(repo,{repo=it},Modifier.fillMaxWidth(),label={Text("Nama repository")},singleLine=true)
                                OutlinedTextField(branch,{branch=it},Modifier.fillMaxWidth(),label={Text("Branch",)} ,singleLine=true)
                                Button(onClick={ if(token.isNotBlank() && owner.isNotBlank() && repo.isNotBlank() && branch.isNotBlank()) { busy=true; status="Memeriksa token..."; lifecycleScope.launch { val result=withContext(Dispatchers.IO){ GitHub.call(token,"GET","/user",null) }; busy=false; if(result.first in 200..299){persist();tokenScreen=false;status="GitHub terhubung"}else status="Token gagal (${result.first}): ${result.second.take(240)}" } } },Modifier.fillMaxWidth(),enabled=!busy) { if(busy) CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp) else Text("MULAI") }
                                Text("Token memerlukan akses repository (Contents: Read and write, Actions: Read and write). Jangan kirim token ke siapa pun.",style=MaterialTheme.typography.bodySmall,color=Color.Gray)
                            }
                        } else when(tab) {
                            0 -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                                Card { Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) { Text("Project ZIP",style=MaterialTheme.typography.titleLarge); Text(zipName,style=MaterialTheme.typography.bodySmall); OutlinedButton(onClick={picker.launch(arrayOf("application/zip","application/octet-stream"))},Modifier.fillMaxWidth()) { Icon(Icons.Default.FolderOpen,null); Spacer(Modifier.width(8.dp)); Text("PILIH FILE ZIP") } } }
                                Card { Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                                    Text("Repository GitHub",style=MaterialTheme.typography.titleLarge)
                                    OutlinedTextField(owner,{owner=it},Modifier.fillMaxWidth(),label={Text("Owner")},singleLine=true)
                                    OutlinedTextField(repo,{repo=it},Modifier.fillMaxWidth(),label={Text("Repository")},singleLine=true)
                                    OutlinedTextField(branch,{branch=it},Modifier.fillMaxWidth(),label={Text("Branch")},singleLine=true)
                                    Text("Mode build")
                                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ FilterChip(variant=="Debug",{variant="Debug"},label={Text("Debug")}); FilterChip(variant=="Release",{variant="Release"},label={Text("Release")}) }
                                    Button(onClick={
                                        if(zipUri==null || token.isBlank() || owner.isBlank() || repo.isBlank() || branch.isBlank()) { status="Pilih ZIP dan lengkapi koneksi GitHub terlebih dahulu"; return@Button }
                                        busy=true;progress=2;logs=emptyList();apkSaved="";tab=0;persist();status="Mempersiapkan upload project..."
                                        lifecycleScope.launch {
                                            try {
                                                val bytes=withContext(Dispatchers.IO){contentResolver.openInputStream(zipUri!!)?.use{it.readBytes()} ?: error("ZIP tidak dapat dibaca")}
                                                require(bytes.size <= 45*1024*1024) { "ZIP lebih dari 45 MB. Batas upload aplikasi ini 45 MB." }
                                                val entries=withContext(Dispatchers.IO){readZip(bytes)}
                                                require(entries.isNotEmpty()) { "ZIP kosong atau tidak valid" }
                                                require(entries.keys.any{it.endsWith("settings.gradle") || it.endsWith("settings.gradle.kts") || it=="gradlew"}) { "ZIP tidak terlihat seperti project Gradle Android (settings.gradle(.kts) atau gradlew tidak ditemukan)" }
                                                log("[OK] ZIP dibaca: ${entries.size} file")
                                                progress=8;status="Memeriksa repository GitHub..."
                                                val outcome=withContext(Dispatchers.IO){GitHub.uploadAndDispatch(token,owner,repo,branch,entries,variant){ msg,p -> runOnUiThread { status=msg;progress=p;log(msg) } }}
                                                log("[OK] Workflow dijalankan: ${outcome}"); status="Build berjalan di GitHub Actions"; progress=20
                                                var done=false; var runUrl=""
                                                for (attempt in 0 until 90) {
                                                    delay(5000)
                                                    val run=withContext(Dispatchers.IO){GitHub.latestRun(token,owner,repo,branch)}
                                                    if(run!=null){runUrl=run.optString("html_url");val st=run.optString("status");val conc=run.optString("conclusion");progress=when(st){"queued"->24;"in_progress"->(30+(attempt%60));else->95};status="GitHub Actions: $st${if(conc!="null") " / $conc" else ""}";log("[ACTIONS] $st ${if(conc!="null") conc else ""}")
                                                        if(st=="completed") { done=true; if(conc=="success") { progress=98; status="Build sukses. Mengunduh artifact..."; val artifact=withContext(Dispatchers.IO){GitHub.downloadApk(token,owner,repo,branch)}; if(artifact!=null){ val saved=withContext(Dispatchers.IO){saveApk(this@MainActivity,artifact)};apkSaved=saved;progress=100;status="Build berhasil! APK disimpan di Downloads/APKBuilder";log("[OK] APK tersimpan: $saved");val h="${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",java.util.Locale.getDefault()).format(java.util.Date())} • $variant • BERHASIL";history=listOf(h)+history; prefs.edit().putString("history",history.take(50).joinToString("\n")).apply() }else {status="Build sukses, tetapi artifact APK tidak ditemukan. Buka log Actions: $runUrl";log("[ERROR] Artifact tidak ditemukan")}} else {status="Build gagal. Buka log GitHub untuk detail: $runUrl";log("[ERROR] Build gagal: $runUrl");val h="${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",java.util.Locale.getDefault()).format(java.util.Date())} • $variant • GAGAL";history=listOf(h)+history;prefs.edit().putString("history",history.take(50).joinToString("\n")).apply() };break }
                                                    }
                                                }
                                                if(!done) status="Build masih berjalan. Cek GitHub Actions untuk status terbaru."
                                            } catch(e:Exception){status="Gagal: ${e.message ?: "kesalahan tidak diketahui"}";log("[ERROR] ${e.message}")}
                                            finally {busy=false}
                                        }
                                    },Modifier.fillMaxWidth().height(54.dp),enabled=!busy){Icon(Icons.Default.Build,null);Spacer(Modifier.width(8.dp));Text("MULAI BUILD SUNGGUHAN")}
                                } }
                                Card { Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                                    Row(verticalAlignment=Alignment.CenterVertically){Text("LIVE BUILD",style=MaterialTheme.typography.titleLarge);Spacer(Modifier.weight(1f));if(busy)CircularProgressIndicator(Modifier.size(20.dp),strokeWidth=2.dp)}
                                    Text("🔨",style=MaterialTheme.typography.displayMedium,modifier=Modifier.align(Alignment.CenterHorizontally).rotate(hammerMotion.value))
                                    Text("$progress%",style=MaterialTheme.typography.headlineMedium,color=Blue,modifier=Modifier.align(Alignment.CenterHorizontally))
                                    LinearProgressIndicator(progress={progress/100f},Modifier.fillMaxWidth())
                                    Text(status)
                                    logs.takeLast(30).forEach{Text(it,style=MaterialTheme.typography.bodySmall,color=if(it.contains("ERROR"))Color.Red else Color.DarkGray)}
                                    if(apkSaved.isNotBlank()) Text("APK: $apkSaved",color=Color(0xFF16834A))
                                    if(!busy && status.contains("GitHub Actions")) TextButton(onClick={tokenScreen=false}){Text("Buka kembali pengaturan GitHub")}
                                } }
                                TextButton(onClick={tokenScreen=true}){Text("Pengaturan Token GitHub")}
                            }
                            1 -> Column(Modifier.fillMaxSize().padding(16.dp)){Text("Riwayat Build",style=MaterialTheme.typography.headlineSmall);LazyColumn {items(history){Text(it,Modifier.fillMaxWidth().padding(12.dp));HorizontalDivider()} } }
                            2 -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("Panduan",style=MaterialTheme.typography.headlineSmall);Text("1. Buat GitHub repository kosong atau gunakan repository milikmu.\n2. Buat Fine-grained Personal Access Token dengan akses Contents Read and write serta Actions Read and write.\n3. Masukkan owner, nama repository, dan branch.\n4. Pilih ZIP project Android yang berisi Gradle wrapper/settings.gradle.\n5. Pilih Debug atau Release lalu mulai build.\n6. Tunggu GitHub Actions selesai; APK akan disimpan di folder Downloads/APKBuilder.");Text("Build dilakukan di GitHub Actions, bukan secara lokal di HP.") }
                            else -> Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Info APK Builder",style=MaterialTheme.typography.headlineSmall);Text("APK Builder 1.1\nBuild Android project melalui GitHub Actions.\nProgress dan hasil berasal dari status workflow GitHub.");TextButton(onClick={tokenScreen=true}){Text("Ganti token / akun GitHub")}}
                        }
                    }
                }
            }
        }
    }
}

private fun readZip(bytes:ByteArray):LinkedHashMap<String,ByteArray>{
 val raw=linkedMapOf<String,ByteArray>(); ZipInputStream(bytes.inputStream()).use{z->var e=z.nextEntry;while(e!=null){if(!e.isDirectory){val n=e.name.replace('\\','/').trimStart('/');if(n.split('/').any{it==".."}) error("ZIP berisi path tidak aman");if(n.isNotBlank())raw[n]=z.readBytes()};z.closeEntry();e=z.nextEntry}}
 val first=raw.keys.map{it.substringBefore('/')}.distinct(); val prefix=if(first.size==1 && raw.keys.all{it.contains('/')} && raw.keys.any{it.substringAfter('/',"").endsWith("settings.gradle") || it.substringAfter('/',"").endsWith("settings.gradle.kts")}) first[0]+"/" else ""
 return if(prefix.isEmpty()) raw else raw.entries.associateTo(linkedMapOf()){(k,v)->k.removePrefix(prefix) to v}
}
private fun saveApk(ctx:Context,apk:ByteArray):String { val name="APKBuilder-${System.currentTimeMillis()}.apk";val values=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,name);put(MediaStore.Downloads.MIME_TYPE,"application/vnd.android.package-archive");put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/APKBuilder")};val uri=ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values)?:error("Tidak bisa membuat file Download");ctx.contentResolver.openOutputStream(uri)?.use{it.write(apk)}?:error("Tidak bisa menyimpan APK");return "Downloads/APKBuilder/$name" }

private object GitHub {
 private fun req(token:String,method:String,path:String,body:JSONObject?=null,raw:ByteArray?=null):Pair<Int,ByteArray>{val b=when{body!=null->body.toString().toRequestBody("application/json".toMediaType());raw!=null->raw.toRequestBody("application/vnd.github+json".toMediaType());method=="GET"->null;else->ByteArray(0).toRequestBody(null)};val request=Request.Builder().url(API+path).header("Authorization","Bearer $token").header("Accept","application/vnd.github+json").header("X-GitHub-Api-Version","2022-11-28").method(method,b).build();http.newCall(request).execute().use{r->return r.code to (r.body?.bytes()?:ByteArray(0))} }
 fun call(token:String,method:String,path:String,body:JSONObject?):Pair<Int,String>{val r=req(token,method,path,body);return r.first to r.second.toString(Charsets.UTF_8)}
 fun uploadAndDispatch(token:String,owner:String,repo:String,branch:String,files:Map<String,ByteArray>,variant:String,update:(String,Int)->Unit):String {
  val base="/repos/$owner/$repo";var r=req(token,"GET",base);if(r.first !in 200..299) error("Repository tidak dapat diakses (${r.first}): ${r.second.toString(Charsets.UTF_8).take(300)}")
  val ref=req(token,"GET","$base/git/ref/heads/${branch}");if(ref.first !in 200..299) error("Branch '$branch' tidak ditemukan (${ref.first})")
  val parent=JSONObject(ref.second.toString(Charsets.UTF_8)).getJSONObject("object").getString("sha")
  val treeItems=JSONArray();var index=0
  val workflow="""name: APK Builder\non:\n  workflow_dispatch:\n    inputs:\n      variant:\n        description: Build type\n        required: true\n        type: choice\n        options: [Debug, Release]\njobs:\n  build:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - name: Set up JDK 17\n        uses: actions/setup-java@v4\n        with:\n          distribution: temurin\n          java-version: '17'\n      - name: Set up Android SDK\n        uses: android-actions/setup-android@v3\n      - name: Make Gradle wrapper executable\n        run: chmod +x ./gradlew\n      - name: Build APK\n        run: ./gradlew --no-daemon assemble${'$'}{{ github.event.inputs.variant }}\n      - name: Upload APK\n        uses: actions/upload-artifact@v4\n        with:\n          name: apk-${'$'}{{ github.event.inputs.variant }}\n          path: '**/build/outputs/apk/**/*.apk'\n          if-no-files-found: error\n""".replace("\\n","\n")
  val all=LinkedHashMap(files);all[".github/workflows/apk-builder.yml"]=workflow.toByteArray()
  for((path,data) in all){index++;update("Mengunggah file $index/${all.size}: ${path.take(55)}",8+(index*65/all.size));val blob=JSONObject().put("content",android.util.Base64.encodeToString(data,android.util.Base64.NO_WRAP)).put("encoding","base64");val br=req(token,"POST","$base/git/blobs",blob);if(br.first !in 200..299)error("Upload blob gagal (${br.first}): ${br.second.toString(Charsets.UTF_8).take(250)}");val sha=JSONObject(br.second.toString(Charsets.UTF_8)).getString("sha");treeItems.put(JSONObject().put("path",path).put("mode","100644").put("type","blob").put("sha",sha)) }
  update("Membuat commit project...",78);val parentCommit=req(token,"GET","$base/git/commits/$parent");if(parentCommit.first !in 200..299)error("Membaca commit branch gagal");val baseTree=JSONObject(parentCommit.second.toString(Charsets.UTF_8)).getJSONObject("tree").getString("sha");val treeBody=JSONObject().put("base_tree",baseTree).put("tree",treeItems);val tr=req(token,"POST","$base/git/trees",treeBody);if(tr.first !in 200..299)error("Membuat Git tree gagal (${tr.first})");val treeSha=JSONObject(tr.second.toString(Charsets.UTF_8)).getString("sha")
  val commit=req(token,"POST","$base/git/commits",JSONObject().put("message","APK Builder: upload Android project").put("tree",treeSha).put("parents",JSONArray().put(parent)));if(commit.first !in 200..299)error("Commit gagal (${commit.first})");val commitSha=JSONObject(commit.second.toString(Charsets.UTF_8)).getString("sha")
  val updateRef=req(token,"PATCH","$base/git/refs/heads/$branch",JSONObject().put("sha",commitSha));if(updateRef.first !in 200..299)error("Update branch gagal (${updateRef.first})")
  update("Menjalankan GitHub Actions...",88);val dispatch=req(token,"POST","$base/actions/workflows/apk-builder.yml/dispatches",JSONObject().put("ref",branch).put("inputs",JSONObject().put("variant",variant)));if(dispatch.first !in 200..299)error("Workflow dispatch gagal (${dispatch.first}): ${dispatch.second.toString(Charsets.UTF_8).take(300)}");return "workflow_dispatch diterima"
 }
 fun latestRun(token:String,owner:String,repo:String,branch:String):JSONObject? {val r=req(token,"GET","/repos/$owner/$repo/actions/workflows/apk-builder.yml/runs?branch=$branch&per_page=1");if(r.first !in 200..299)return null;val a=JSONObject(r.second.toString(Charsets.UTF_8)).optJSONArray("workflow_runs")?:return null;return if(a.length()>0)a.getJSONObject(0)else null}
 fun downloadApk(token:String,owner:String,repo:String,branch:String):ByteArray? {val runs=req(token,"GET","/repos/$owner/$repo/actions/workflows/apk-builder.yml/runs?branch=$branch&per_page=1");if(runs.first !in 200..299)return null;val run=JSONObject(runs.second.toString(Charsets.UTF_8)).optJSONArray("workflow_runs")?.optJSONObject(0)?:return null;val ar=req(token,"GET","/repos/$owner/$repo/actions/runs/${run.getLong("id")}/artifacts");if(ar.first !in 200..299)return null;val arr=JSONObject(ar.second.toString(Charsets.UTF_8)).optJSONArray("artifacts")?:return null;val artifact=(0 until arr.length()).map{arr.getJSONObject(it)}.firstOrNull{!it.optBoolean("expired") }?:return null;val dl=req(token,"GET","/repos/$owner/$repo/actions/artifacts/${artifact.getLong("id")}/zip");if(dl.first !in 200..299)return null;ZipInputStream(dl.second.inputStream()).use{z->var e=z.nextEntry;while(e!=null){if(!e.isDirectory && e.name.endsWith(".apk",true))return z.readBytes();e=z.nextEntry}};return null }
}
