# TEETH TRAP 3D
Project Android Kotlin native, landscape orientation.

## Fitur versi awal
- Menu utama: Bermain, Pengaturan, Cara Bermain.
- Pilihan karakter cowok/cewek.
- Pengaturan kualitas grafis dan volume (pengaturan volume disiapkan untuk update audio).
- Game horizontal melawan BOT.
- Meja berputar saat pergantian giliran.
- Gigi jebakan diacak setiap ronde.
- Efek suara belum dimasukkan sesuai permintaan.

## Build APK
Buka folder ini di Android Studio, tunggu Gradle sync, lalu pilih Build > Build APK(s).
APK debug berada di `app/build/outputs/apk/debug/app-debug.apk`.

Project ini mengikuti struktur Gradle Android pada ZIP contoh yang diberikan. Build belum dijalankan di lingkungan ini, jadi instalasi dan kompilasi akhir perlu diverifikasi melalui Android Studio/Gradle.


Launcher icon: menggunakan gambar gameplay monster yang diberikan, dipotong menjadi ikon persegi dan dipasang pada resource mipmap Android (termasuk adaptive icon).
