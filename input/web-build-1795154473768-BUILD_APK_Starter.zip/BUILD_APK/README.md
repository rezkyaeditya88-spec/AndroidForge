# BUILD APK — Android starter project

Ini adalah proyek Android native Kotlin untuk mengendalikan build source Android melalui GitHub Actions.

## Yang sudah tersedia
- Aplikasi Android dengan tema biru-putih.
- Ikon aplikasi menggunakan gambar yang diberikan pengguna.
- Input GitHub Personal Access Token (disimpan terenkripsi di perangkat).
- Input owner, repository, dan branch.
- Pemilih source ZIP.
- Upload ZIP ke repository melalui GitHub Contents API.
- Trigger workflow `build-source.yml` melalui GitHub Actions.
- Workflow build APK debug/release dan mengunggah APK sebagai GitHub Artifact.

## Cara menggunakan
1. Buat repository GitHub baru, misalnya `build-apk`.
2. Upload seluruh isi ZIP proyek ini ke repository tersebut pada branch `main`.
3. Pastikan GitHub Actions diaktifkan pada repository.
4. Buat Fine-grained Personal Access Token untuk repository tersebut dengan izin:
   - Contents: Read and write
   - Actions: Read and write
   - Metadata: Read
   Token hanya digunakan pada repository yang dipilih.
5. Build aplikasi Android ini menggunakan Android Studio / GitHub Actions.
6. Instal aplikasi BUILD APK di HP.
7. Masukkan token, owner, nama repository, branch, lalu pilih source ZIP Android.
8. Tekan BUILD APK.
9. Buka tab Actions pada repository untuk melihat log dan mengunduh artifact APK.

## Batasan versi awal
- Upload menggunakan GitHub Contents API, sehingga ZIP dibatasi 50 MB oleh aplikasi ini.
- Repository tujuan harus sudah berisi `.github/workflows/build-source.yml` dari proyek ini.
- Workflow `auto` saat ini menjalankan `assembleDebug`; pilihan release menjalankan `assembleRelease`.
- APK dihasilkan sebagai GitHub Actions Artifact (retensi 14 hari), belum diunduh langsung dari aplikasi.
- Build release yang membutuhkan signing key khusus belum dikonfigurasi. Jangan menganggap APK release siap distribusi sebelum signing disiapkan.
- Smart Error Fix, live log streaming, pemilih repository otomatis, dan download artifact langsung di aplikasi adalah tahap pengembangan berikutnya.

## Keamanan
Jangan pernah mengirim token ke orang lain atau memasukkannya ke screenshot. Token disimpan dengan AndroidX EncryptedSharedPreferences pada perangkat, tetapi tetap cabut token dari GitHub jika perangkat hilang atau token terungkap.
