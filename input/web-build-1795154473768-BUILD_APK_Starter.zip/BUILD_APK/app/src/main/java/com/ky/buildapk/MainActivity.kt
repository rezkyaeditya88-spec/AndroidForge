package com.ky.buildapk

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.InputStream
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val client = OkHttpClient()
    private val executor = Executors.newSingleThreadExecutor()
    private val pickZip = 1001
    private var zipUri: Uri? = null
    private lateinit var token: EditText
    private lateinit var owner: EditText
    private lateinit var repo: EditText
    private lateinit var branch: EditText
    private lateinit var fileLabel: TextView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var buildButton: Button
    private lateinit var variant: Spinner
    private val prefs by lazy {
        val master = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(this, "secure_settings", master,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        token = findViewById(R.id.tokenInput)
        owner = findViewById(R.id.ownerInput)
        repo = findViewById(R.id.repoInput)
        branch = findViewById(R.id.branchInput)
        fileLabel = findViewById(R.id.fileLabel)
        status = findViewById(R.id.statusText)
        progress = findViewById(R.id.progress)
        buildButton = findViewById(R.id.buildButton)
        variant = findViewById(R.id.variantSpinner)
        token.setText(prefs.getString("github_token", ""))
        variant.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("debug", "release", "auto"))
        findViewById<Button>(R.id.pickZipButton).setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip"
            }
            startActivityForResult(intent, pickZip)
        }
        buildButton.setOnClickListener { startBuild() }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickZip && resultCode == RESULT_OK) {
            zipUri = data?.data
            fileLabel.text = zipUri?.lastPathSegment ?: "ZIP dipilih"
        }
    }

    private fun startBuild() {
        val pat = token.text.toString().trim()
        val user = owner.text.toString().trim()
        val repository = repo.text.toString().trim()
        val ref = branch.text.toString().trim().ifBlank { "main" }
        val uri = zipUri
        if (pat.isBlank() || user.isBlank() || repository.isBlank() || uri == null) {
            status.text = "Lengkapi token, owner, repository, dan pilih source ZIP."
            return
        }
        prefs.edit().putString("github_token", pat).apply()
        buildButton.isEnabled = false
        progress.visibility = View.VISIBLE
        status.text = "Mengunggah source ZIP ke GitHub..."
        executor.execute {
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                if (bytes.size > 50 * 1024 * 1024) throw Exception("ZIP melebihi batas 50 MB untuk upload API.")
                val api = "https://api.github.com/repos/$user/$repository"
                val headers = mapOf("Authorization" to "Bearer $pat", "Accept" to "application/vnd.github+json",
                    "X-GitHub-Api-Version" to "2022-11-28", "User-Agent" to "BUILD-APK-Android")
                val branchReq = Request.Builder().url("$api").apply { headers.forEach { (k,v) -> addHeader(k,v) } }.get().build()
                client.newCall(branchReq).execute().use { if (!it.isSuccessful) throw Exception("Repository tidak bisa diakses: HTTP ${it.code}") }
                val path = "build-apk-input/source-${System.currentTimeMillis()}.zip"
                val uploadJson = JSONObject().put("message", "BUILD APK: upload source ZIP")
                    .put("content", Base64.encodeToString(bytes, Base64.NO_WRAP)).put("branch", ref)
                val uploadReq = Request.Builder().url("$api/contents/$path")
                    .apply { headers.forEach { (k,v) -> addHeader(k,v) } }
                    .put(uploadJson.toString().toRequestBody("application/json".toMediaType())).build()
                client.newCall(uploadReq).execute().use {
                    if (!it.isSuccessful) throw Exception("Upload ZIP gagal: HTTP ${it.code} ${it.body?.string().orEmpty()}")
                }
                runOnUiThread { status.text = "ZIP terunggah. Menjalankan GitHub Actions..." }
                val dispatch = JSONObject().put("ref", ref).put("inputs",
                    JSONObject().put("source_zip_path", path).put("build_variant", variant.selectedItem.toString()))
                val dispatchReq = Request.Builder().url("$api/actions/workflows/build-source.yml/dispatches")
                    .apply { headers.forEach { (k,v) -> addHeader(k,v) } }
                    .post(dispatch.toString().toRequestBody("application/json".toMediaType())).build()
                client.newCall(dispatchReq).execute().use {
                    if (it.code != 204) throw Exception("Workflow dispatch gagal: HTTP ${it.code}. Pastikan workflow tersedia dan token punya izin Actions.")
                }
                runOnUiThread { status.text = "Build berhasil dikirim ke GitHub Actions. Buka tab Actions di repository untuk melihat progres dan mengunduh artifact." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Gagal: ${e.message}" }
            } finally {
                runOnUiThread { progress.visibility = View.GONE; buildButton.isEnabled = true }
            }
        }
    }
}
